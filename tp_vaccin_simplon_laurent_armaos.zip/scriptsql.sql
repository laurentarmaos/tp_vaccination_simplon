#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: specialite
#------------------------------------------------------------

CREATE TABLE specialite(
        id_spe  Int  Auto_increment  NOT NULL ,
        nom_spe Varchar (50) NOT NULL
	,CONSTRAINT specialite_PK PRIMARY KEY (id_spe)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: ecole
#------------------------------------------------------------

CREATE TABLE ecole(
        id_ecole    Int  Auto_increment  NOT NULL ,
        nom_ecole   Varchar (50) NOT NULL ,
        num_voie    Int NOT NULL ,
        voie        Varchar (50) NOT NULL ,
        code_postal Varchar (5) NOT NULL ,
        ville       Varchar (50) NOT NULL
	,CONSTRAINT ecole_PK PRIMARY KEY (id_ecole)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: centre_medical
#------------------------------------------------------------

CREATE TABLE centre_medical(
        id_cm       Int  Auto_increment  NOT NULL ,
        nom_cm      Varchar (50) NOT NULL ,
        num_voie    Int NOT NULL ,
        voie        Varchar (50) NOT NULL ,
        code_postal Varchar (5) NOT NULL ,
        ville       Varchar (50) NOT NULL
	,CONSTRAINT centre_medical_PK PRIMARY KEY (id_cm)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: medecin
#------------------------------------------------------------

CREATE TABLE medecin(
        identifiant_medecin Int NOT NULL ,
        nom_medecin         Varchar (50) NOT NULL ,
        prenom_medecin      Varchar (50) NOT NULL ,
        id_cm               Int NOT NULL
	,CONSTRAINT medecin_PK PRIMARY KEY (identifiant_medecin)

	,CONSTRAINT medecin_centre_medical_FK FOREIGN KEY (id_cm) REFERENCES centre_medical(id_cm)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: enfant
#------------------------------------------------------------

CREATE TABLE enfant(
        id_enfant     Int  Auto_increment  NOT NULL ,
        nom_enfant    Varchar (50) NOT NULL ,
        prenom_enfant Varchar (50) NOT NULL ,
        age_enfant    Int NOT NULL ,
        sexe_enfant   Varchar (50) NOT NULL ,
        poids_enfant  Int NOT NULL ,
        taille_enfant Int NOT NULL ,
        id_ecole      Int NOT NULL
	,CONSTRAINT enfant_PK PRIMARY KEY (id_enfant)

	,CONSTRAINT enfant_ecole_FK FOREIGN KEY (id_ecole) REFERENCES ecole(id_ecole)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: categorie
#------------------------------------------------------------

CREATE TABLE categorie(
        code_cat Varchar (50) NOT NULL ,
        nom_cat  Varchar (50) NOT NULL
	,CONSTRAINT categorie_PK PRIMARY KEY (code_cat)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: vaccin
#------------------------------------------------------------

CREATE TABLE vaccin(
        id_vaccin  Int  Auto_increment  NOT NULL ,
        nom_vaccin Varchar (50) NOT NULL ,
        code_cat   Varchar (50) NOT NULL
	,CONSTRAINT vaccin_PK PRIMARY KEY (id_vaccin)

	,CONSTRAINT vaccin_categorie_FK FOREIGN KEY (code_cat) REFERENCES categorie(code_cat)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: specialisation
#------------------------------------------------------------

CREATE TABLE specialisation(
        id_spe              Int NOT NULL ,
        identifiant_medecin Int NOT NULL
	,CONSTRAINT specialisation_PK PRIMARY KEY (id_spe,identifiant_medecin)

	,CONSTRAINT specialisation_specialite_FK FOREIGN KEY (id_spe) REFERENCES specialite(id_spe)
	,CONSTRAINT specialisation_medecin0_FK FOREIGN KEY (identifiant_medecin) REFERENCES medecin(identifiant_medecin)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: affectation
#------------------------------------------------------------

CREATE TABLE affectation(
        id_ecole            Int NOT NULL ,
        identifiant_medecin Int NOT NULL
	,CONSTRAINT affectation_PK PRIMARY KEY (id_ecole,identifiant_medecin)

	,CONSTRAINT affectation_ecole_FK FOREIGN KEY (id_ecole) REFERENCES ecole(id_ecole)
	,CONSTRAINT affectation_medecin0_FK FOREIGN KEY (identifiant_medecin) REFERENCES medecin(identifiant_medecin)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: vaccination
#------------------------------------------------------------

CREATE TABLE vaccination(
        id_enfant           Int NOT NULL ,
        identifiant_medecin Int NOT NULL ,
        id_ecole            Int NOT NULL ,
        id_vaccin           Int NOT NULL ,
        date_vaccination    Date NOT NULL
	,CONSTRAINT vaccination_PK PRIMARY KEY (id_enfant,identifiant_medecin,id_ecole,id_vaccin)

	,CONSTRAINT vaccination_enfant_FK FOREIGN KEY (id_enfant) REFERENCES enfant(id_enfant)
	,CONSTRAINT vaccination_medecin0_FK FOREIGN KEY (identifiant_medecin) REFERENCES medecin(identifiant_medecin)
	,CONSTRAINT vaccination_ecole1_FK FOREIGN KEY (id_ecole) REFERENCES ecole(id_ecole)
	,CONSTRAINT vaccination_vaccin2_FK FOREIGN KEY (id_vaccin) REFERENCES vaccin(id_vaccin)
)ENGINE=InnoDB;

