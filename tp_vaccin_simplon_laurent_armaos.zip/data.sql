INSERT INTO categorie (code_cat, nom_cat)
values ("az123", "catégorie1");


INSERT INTO centre_medical (nom_cm, num_voie, voie, code_postal, ville)
values ("centre1", 5, "rue1", 42424, "ville1")

INSERT INTO ecole (nom_ecole, num_voie, voie, code_postal, ville)
values ("ecole1", 10, "rue1", 42424, "ville1")

INSERT INTO enfant (nom_enfant, prenom_enfant, age_enfant, sexe_enfant, poids_enfant, taille_enfant, id_ecole)
VALUES ("nom1", "prenom1", 10, "m", 30, 130, (
SELECT id_ecole FROM ecole WHERE nom_ecole = "ecole1"))

INSERT INTO medecin (identifiant_medecin, nom_medecin, prenom_medecin, id_cm)
VALUES (ROUND(RAND()*(100000), -1), "nom1", "prenom1", (
SELECT id_cm FROM centre_medical WHERE nom_cm = "centre1"))

INSERT INTO specialite (nom_spe)
VALUES ("specialite1")

INSERT INTO specialisation (id_spe, identifiant_medecin)
VALUES ((SELECT id_spe FROM specialite WHERE nom_spe = "specialite1"), 
(SELECT identifiant_medecin FROM medecin WHERE nom_medecin = "nom1"))

INSERT INTO affectation (id_ecole, identifiant_medecin)
VALUES ((SELECT id_ecole FROM ecole WHERE nom_ecole = "ecole1"),
(SELECT identifiant_medecin FROM medecin WHERE nom_medecin = "nom1"))

INSERT INTO vaccin (nom_vaccin, code_cat)
VALUES("vaccin1", (SELECT code_cat FROM categorie WHERE nom_cat = "catégorie1"))

INSERT INTO vaccination (id_enfant, identifiant_medecin, id_ecole, id_vaccin, date_vaccination)
VALUES((SELECT id_enfant from enfant WHERE nom_enfant = "nom1"),
		(SELECT identifiant_medecin FROM medecin WHERE nom_medecin = "nom1"),
		(SELECT id_ecole FROM ecole WHERE nom_ecole = "ecole1"),
		(SELECT id_vaccin FROM vaccin WHERE nom_vaccin = "vaccin1"),
		(NOW()))